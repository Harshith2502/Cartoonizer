# AI-Chat_bot
AI ChatBot using Python Tensorflow and Natural Language Processing (NLP) along side tfLearn.
The intent file used for training is based on a customer care Chatbot by using which you can know which kind of services does the Cyber Industry provides.

# Dependencies
1. pip3 install nltk
2. pip3 install tensorflow
3. pip3 install numpy
4. pip3 install tflearn
5. pip3 install random
6. pip3 install json
